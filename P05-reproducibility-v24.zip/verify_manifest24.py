"""Verify every release payload against its non-circular SHA256 manifest."""
from pathlib import Path
import hashlib
import json

r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST24.json').read_text())
for name,want in m['files'].items():
    p=(r/name).resolve()
    assert p.is_relative_to(r.resolve()) and p.is_file(),name
    assert hashlib.sha256(p.read_bytes()).hexdigest()==want,name
print(json.dumps({'status':'PASS','verified_payloads':len(m['files']),'manifest_excludes_itself':True}))
