"""Frozen empirical response preflight. No interface outcomes in this program."""
import json, hashlib, datetime, time, resource, sys, platform
from pathlib import Path
import numpy as np
from scipy.io import loadmat
from scipy.optimize import least_squares
from scipy.signal import lfilter
from scipy.linalg import expm
ROOT=Path(__file__).resolve().parent
PLAN=json.loads((ROOT/'PREFLIGHT_PLAN01.json').read_text())
DT=0.01

def coefficients(params, dt=DT):
    k,t1,t2=params
    e1,e2=np.exp(-dt/t1),np.exp(-dt/t2)
    if abs(t1-t2)<1e-8*max(t1,t2):
        c=(dt/t1)*e1
    else:
        c=t1/(t1-t2)*(e1-e2)
    return k,e1,e2,c,1-e2-c

def predict(params,u,r0):
    k,e1,e2,c,d=coefficients(params)
    n=np.arange(len(u))
    x=lfilter([0,1-e1],[1,-e1],k*u)+e1**n*r0
    r=lfilter([0,1],[1,-e2],c*x+d*k*u)+e2**n*r0
    return r

def segments(name):
    raw=loadmat(ROOT/name,simplify_cells=True)
    data=raw['CCData']
    vals={k:np.asarray(data[k]['data'],dtype=float) for k in ['time','swa','v_x','Psi_d']}
    t=vals['time']; assert np.all(np.diff(t)>0)
    assert np.max(np.abs(np.diff(t)-DT))<1e-6
    assert data['swa']['unit']=='rad' and data['Psi_d']['unit']=='rad/s' and data['v_x']['unit']=='m/s'
    good=np.logical_and.reduce([np.isfinite(a) for a in vals.values()]) & (vals['v_x']>=5)
    edges=np.flatnonzero(np.diff(np.r_[False,good,False].astype(int)))
    out=[]
    for begin,end in zip(edges[::2],edges[1::2]):
        if t[end-1]-t[begin]<5: continue
        grid=np.arange(0,int(np.floor((t[end-1]-t[begin])/DT+1e-8))+1)*DT+t[begin]
        ix=np.searchsorted(t,grid+1e-9,side='right')-1
        ix=np.clip(ix,begin,end-1)
        out.append({'start_s':float(t[begin]),'end_s':float(t[end-1]),'t':grid,'u':vals['v_x'][ix]*vals['swa'][ix],'r':np.interp(grid,t,vals['Psi_d']),'v':vals['v_x'][ix],'swa':vals['swa'][ix]})
    assert out, name+' has no qualifying segment'
    return {'name':name,'info':str(data['info']),'segments':out,'source_sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest(),'time_Ts':float(data['time']['Ts'])}

def record_metrics(rec,params):
    obs=[]; preds=[]
    for s in rec['segments']:
        pred=predict(params,s['u'],s['r'][0]); s['prediction']=pred
        obs.extend(s['r'][100:]); preds.extend(pred[100:])
    y=np.array(obs); p=np.array(preds)
    rmse=float(np.sqrt(np.mean((p-y)**2)))
    return {'record':rec['name'],'source_info':rec['info'],'source_sha256':rec['source_sha256'],'segments':len(rec['segments']),'scored_samples':len(y),'scored_duration_s':len(y)*DT,'RMSE_rad_s':rmse,'NRMSE':rmse/float(np.std(y)),'correlation':float(np.corrcoef(y,p)[0,1]),'yaw_std_rad_s':float(np.std(y)),'bounds_s':[[s['start_s'],s['end_s']] for s in rec['segments']]}

def tests():
    evidence=[]
    for p in [[0.02,0.1,0.2],[0.02,0.1,0.1],[-0.02,0.3,0.1]]:
        k,t1,t2=p; dt=DT
        A=np.array([[-1/t1,0],[1/t2,-1/t2]])
        B=np.array([[k/t1],[0]])
        block=np.zeros((3,3)); block[:2,:2]=A; block[:2,2:]=B
        M=expm(block*dt)
        u=np.sin(np.arange(200)*0.13); state=np.array([0.2,0.2]); seq=[]
        for v in u:
            seq.append(state[1]); state=M[:2,:2]@state+M[:2,2]*v
        err=float(np.max(np.abs(predict(p,u,0.2)-seq)))
        assert err<1e-12,err
        evidence.append({'params':p,'expm_max_error':err})
    p=[0.03,0.1,0.2]; u=np.zeros(100); assert np.max(np.abs(predict(p,u,0)))==0
    # The sign of all states and input reverses in this linear model.
    assert np.allclose(predict(p,-u,-0.3),-predict(p,u,0.3),atol=1e-14)
    return evidence

def run_fit():
    dest=ROOT/'fit01'; dest.mkdir(exist_ok=False)
    start=time.time(); test=tests()
    records=[segments(n) for n in PLAN['fit_files']]
    def residual(params):
        pieces=[]
        for rec in records:
            n=sum(len(s['r'])-100 for s in rec['segments'])
            for s in rec['segments']:
                pieces.append((predict(params,s['u'],s['r'][0])[100:]-s['r'][100:])/np.sqrt(n))
        return np.concatenate(pieces)
    result=least_squares(residual,[0.025,0.1,0.2],bounds=([-1,0.01,0.01],[1,3,3]),max_nfev=200,xtol=1e-12,ftol=1e-12,gtol=1e-12)
    metrics=[record_metrics(r,result.x) for r in records]
    report={'status':'FIT_LOCKED' if result.success else 'FAILED_FIT','params':dict(zip(['K','tau1_s','tau2_s'],result.x.tolist())),'success':bool(result.success),'message':result.message,'nfev':result.nfev,'cost':float(result.cost),'optimality':float(result.optimality),'metrics':metrics,'tests':test,'elapsed_s':time.time()-start,'process_cpu_s':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'frozen_plan_sha256':hashlib.sha256((ROOT/'PREFLIGHT_PLAN01.json').read_bytes()).hexdigest(),'code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'numpy':np.__version__,'platform':platform.platform(),'heldout_rows_accessed':False}
    (dest/'FIT_LOCK01.json').write_text(json.dumps(report,indent=2))
    print(json.dumps(report,indent=2))
    assert result.success
    assert report['process_cpu_s']<300 and report['elapsed_s']<600

if __name__=='__main__':
    run_fit()
