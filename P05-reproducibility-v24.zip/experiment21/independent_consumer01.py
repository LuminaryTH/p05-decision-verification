"""Separate scalar consumer. Does not import the acquisition simulator or predictor."""
import json, hashlib, math, datetime
from pathlib import Path
import numpy as np
from scipy.io import loadmat
ROOT=Path(__file__).resolve().parent

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def simulate_scalar(v,target,params,gain,interface,method,hms,schedule=None):
    K,t1,t2=params
    if method=='exact':
        a=math.exp(-.01/t1); d=math.exp(-.01/t2)
        c=t1/(t1-t2)*(a-d) if abs(t1-t2)>1e-10 else .01/t1*a
    else:
        h=hms/1000
        def rhs(x,r,u): return ((K*u-x)/t1,(x-r)/t2)
        def step(x,r,u):
            if method=='Euler':
                q,w=rhs(x,r,u); return x+h*q,r+h*w
            q1,w1=rhs(x,r,u); q2,w2=rhs(x+h*q1/2,r+h*w1/2,u); q3,w3=rhs(x+h*q2/2,r+h*w2/2,u); q4,w4=rhs(x+h*q3,r+h*w3,u)
            return x+h*(q1+2*q2+2*q3+q4)/6,r+h*(w1+2*w2+2*w3+w4)/6
        aa,cc=step(1.,0.,0.); _,dd=step(0.,1.,0.)
        n=round(.01/h); a=aa**n; d=dd**n
        c=cc*(a-d)/(aa-dd) if abs(aa-dd)>1e-12 else cc*n*aa**(n-1)
    b1=K*(1-a); b2=K*(1-d-c)
    x=r=float(target[0]); states=[]; applied=[]; cmds=[]
    for j,(speed,ref) in enumerate(zip(v,target)):
        states.append([x,r])
        if j%10==0:
            if schedule is None:
                u=max(-3,min(3,(ref+gain*(ref-r))/(K*speed)))
                if interface=='quantized':
                    grid=[-3+i*6/98 for i in range(99)]
                    u=min(grid,key=lambda val:abs(val-u))
            else: u=float(schedule[j//10])
            cmds.append(u)
        applied.append(u)
        x,r=a*x+b1*speed*u,c*x+d*r+b2*speed*u
    residual=[state[1]-float(y) for state,y in zip(states,target)]
    score=math.fsum(min(25,(e/.1)**2) for e in residual[100:])/len(residual[100:])
    return np.array(states),np.array(applied),np.array(cmds),score

def main():
    result=json.loads((ROOT/'experiment01/RESULTS01.json').read_text())
    repeat=json.loads((ROOT/'experiment02/RESULTS01.json').read_text())
    lock=json.loads((ROOT/'fit01/FIT_LOCK01.json').read_text())
    params=[lock['params'][k] for k in ['K','tau1_s','tau2_s']]
    assert result['raw_files']==repeat['raw_files'] and result['scores']==repeat['scores'] and result['conditions']==repeat['conditions'] and result['replay']==repeat['replay']
    errors=[]; scoremap={}
    for fname,digest in result['raw_files'].items():
        path=ROOT/'experiment01'/fname; assert sha(path)==digest
    for row in result['scores']:
        cid=row['condition']; source=ROOT/'holdout01'/(row['record'].replace('.mat','')+f"-segment{row['segment']}.npz")
        with np.load(source) as z: v=z['v']; target=z['r']
        h=row['h_ms']; method=row['method']; interface=row['interface']
        name=cid+('-exact-' if method=='exact' else f'-{method}-{h}-')+interface+'.npz'
        a,b,c,score=simulate_scalar(v,target,params,row['gain'],interface,method,h)
        with np.load(ROOT/'experiment01'/name) as raw:
            err=float(np.max(np.abs(a-raw['states']))); assert err<2e-10,(name,err)
            assert np.max(np.abs(b-raw['applied']))<2e-10
            assert np.max(np.abs(c-raw['schedule']))<2e-10
        assert abs(score-row['score'])<2e-10
        errors.append(err); scoremap[(cid,method,h,interface)]=score
    crosscount=0
    for row in result['replay']:
        cid=row['condition']; method=row['method']; src=ROOT/'holdout01'/(row['record'].replace('.mat','')+f"-segment{row['segment']}.npz")
        with np.load(src) as z: v=z['v']; target=z['r']
        for interface in ['continuous','quantized']:
            crossscores={}
            for tag,h,source_h in [('crossfine',.15625,10),('crosscoarse',10,.15625)]:
                with np.load(ROOT/'experiment01'/(cid+f'-{method}-{source_h}-'+interface+'.npz')) as z: schedule=z['schedule']
                a,b,c,score=simulate_scalar(v,target,params,row['gain'],interface,method,h,schedule=schedule)
                with np.load(ROOT/'experiment01'/(cid+f'-{method}-{tag}-'+interface+'.npz')) as z:
                    err=float(np.max(np.abs(a-z['states']))); assert err<2e-10; assert np.max(np.abs(b-z['applied']))<2e-10
                errors.append(err); crossscores[tag]=score; crosscount+=1
            comp=row['components'][interface]
            Cc=scoremap[(cid,method,10,interface)]; Ff=scoremap[(cid,method,.15625,interface)]; Fc=crossscores['crossfine']; Cf=crossscores['crosscoarse']
            quantities={'Cc':Cc,'Fc':Fc,'Cf':Cf,'Ff':Ff,'N':(Fc-Cc+Ff-Cf)/2,'B':(Cf-Cc+Ff-Fc)/2,'I':Ff-Fc-Cf+Cc,'Nc':Fc-Cc,'Bf':Ff-Fc,'Bc':Cf-Cc,'Nf':Ff-Cf}
            for k,val in quantities.items(): assert abs(val-comp[k])<2e-10
    # Check every decision from separately reconstructed scores.
    for row in result['conditions']:
        gaps=[scoremap[(row['condition'],row['method'],h,'quantized')]-scoremap[(row['condition'],row['method'],h,'continuous')] for h in [10,5,2.5,1.25,.625,.3125,.15625]]
        choices=['quantized' if g < -1e-12 else 'continuous' for g in gaps]
        assert choices==row['choices']
        def sg(g): return 1 if g>1e-12 else -1 if g < -1e-12 else 0
        assert (sg(gaps[0])*sg(gaps[-1])==-1)==row['strict_endpoint_reversal']
        origin=choices[0]; costs=[max(0,g if origin=='quantized' else -g) for g in gaps]
        assert abs(max(costs)-row['origin_max_path_regret'])<2e-10
    # No exact moving two-second sample block is duplicated between fit and holdout files.
    calibration=json.loads((ROOT/'calibration-download01.json').read_text()); holdouts=json.loads((ROOT/'holdout-download01.json').read_text())
    def moving_blocks(item):
        d=loadmat(ROOT/item['name'],simplify_cells=True)['CCData']
        a=np.column_stack([d[k]['data'] for k in ['v_x','swa','Psi_d']]).astype('<f8')
        return {hashlib.sha256(a[i:i+200].tobytes()).hexdigest() for i in range(0,len(a)-199,100) if np.min(a[i:i+200,0])>=5}
    fitblocks=set().union(*(moving_blocks(i) for i in calibration))
    overlap={item['name']:len(moving_blocks(item)&fitblocks) for item in holdouts}; assert not any(overlap.values())
    report={'status':'PASS_SEPARATE_SCALAR_AND_FRESH_PROCESS','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'feedback_trajectories':len(result['scores']),'crossed_replays':crosscount,'all_456_raw_hashes_match_repeat':True,'maximum_state_difference':max(errors),'all_choices_and_path_costs_checked':True,'all_replay_components_checked':True,'calibration_holdout_exact_moving_block_overlap':overlap,'source_result_sha256':sha(ROOT/'experiment01/RESULTS01.json'),'repeat_result_sha256':sha(ROOT/'experiment02/RESULTS01.json'),'consumer_code_sha256':sha(Path(__file__)),'boundary':'Separate arithmetic implementation by same assistant; not a third-party replication or independent physical validation. Block check excludes exact copied windows only.'}
    (ROOT/'INDEPENDENT_CHECK01.json').write_text(json.dumps(report,indent=2)); print(json.dumps(report,indent=2))
if __name__=='__main__': main()
