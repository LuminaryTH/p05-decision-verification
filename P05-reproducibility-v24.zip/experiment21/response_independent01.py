"""Separate source-level response check using raw MAT arrays and scalar exact flows."""
import math,json,hashlib,datetime
from pathlib import Path
import numpy as np
from scipy.io import loadmat
ROOT=Path(__file__).resolve().parent
fit=json.loads((ROOT/'fit01/FIT_LOCK01.json').read_text()); gate=json.loads((ROOT/'holdout01/RESPONSE_GATE01.json').read_text())
K=fit['params']['K']; t1=fit['params']['tau1_s']; t2=fit['params']['tau2_s']
a=math.exp(-.01/t1); d=math.exp(-.01/t2); c=t1/(t1-t2)*(a-d)
results=[]; max_pred_error=0
for expected in fit['metrics']+gate['metrics']:
    raw=loadmat(ROOT/expected['record'],simplify_cells=True)['CCData']
    t=np.asarray(raw['time']['data']); v=np.asarray(raw['v_x']['data']); angle=np.asarray(raw['swa']['data']); yaw=np.asarray(raw['Psi_d']['data'])
    assert raw['time']['Ts']==.01 and raw['swa']['unit']=='rad' and raw['Psi_d']['unit']=='rad/s' and raw['v_x']['unit']=='m/s'
    intervals=[]; begin=None
    for i in range(len(t)+1):
        valid=i<len(t) and v[i]>=5 and all(math.isfinite(float(z[i])) for z in [t,v,angle,yaw])
        if valid and begin is None: begin=i
        if not valid and begin is not None:
            if t[i-1]-t[begin]>=5: intervals.append((begin,i))
            begin=None
    observations=[]; predictions=[]
    for segno,(start,end) in enumerate(intervals):
        x=r=float(yaw[start]); pred=[]
        for j in range(start,end):
            pred.append(r); u=float(v[j]*angle[j])
            x,r=a*x+K*(1-a)*u,c*x+d*r+K*(1-d-c)*u
        observations.extend(yaw[start+100:end]); predictions.extend(pred[100:])
        if expected['record'] in [item['record'] for item in gate['metrics']]:
            z=np.load(ROOT/'holdout01'/(expected['record'].replace('.mat','')+f'-segment{segno}.npz'))
            assert len(pred)==len(z['prediction'])
            err=float(np.max(np.abs(np.array(pred)-z['prediction']))); max_pred_error=max(max_pred_error,err); assert err<2e-11
    n=len(observations); mu=math.fsum(map(float,observations))/n
    var=math.fsum((float(v)-mu)**2 for v in observations)/n
    rmse=math.sqrt(math.fsum((float(p)-float(y))**2 for p,y in zip(predictions,observations))/n)
    pmu=math.fsum(predictions)/n
    covariance=math.fsum((float(p)-pmu)*(float(y)-mu) for p,y in zip(predictions,observations))
    corr=covariance/math.sqrt(math.fsum((p-pmu)**2 for p in predictions)*math.fsum((float(y)-mu)**2 for y in observations))
    metrics={'RMSE_rad_s':rmse,'NRMSE':rmse/math.sqrt(var),'correlation':corr}
    for k,vv in metrics.items(): assert abs(vv-expected[k])<2e-11,(expected['record'],k,vv,expected[k])
    assert n==expected['scored_samples'] and len(intervals)==expected['segments']
    results.append(dict(record=expected['record'],segments=len(intervals),scored_samples=n,metrics=metrics))
report={'status':'PASS_RAW_MAT_RESPONSE_RECONSTRUCTION','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'records':results,'max_prediction_difference':max_pred_error,'boundary':'Independent scalar calculation by same assistant; confirms published input identity and all locked response metrics, not physical closed-loop validation','code_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(ROOT/'RESPONSE_INDEPENDENT_CHECK01.json').write_text(json.dumps(report,indent=2)); print(json.dumps(report,indent=2))
