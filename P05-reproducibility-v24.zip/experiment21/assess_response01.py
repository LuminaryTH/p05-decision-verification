import json, hashlib, datetime
from pathlib import Path
import numpy as np
from response_preflight01 import ROOT, PLAN, segments, record_metrics
fit=json.loads((ROOT/'fit01/FIT_LOCK01.json').read_text())
assert fit['status']=='FIT_LOCKED'
params=[fit['params'][x] for x in ['K','tau1_s','tau2_s']]
out=ROOT/'holdout01'; out.mkdir(exist_ok=False)
records=[segments(name) for name in PLAN['holdout_files']]
metrics=[record_metrics(r,params) for r in records]
checks=[]
for rec,m in zip(records,metrics):
    passed=m['NRMSE']<=0.6 and m['correlation']>=0.8 and m['RMSE_rad_s']<=0.1 and m['scored_duration_s']>=5
    checks.append({'record':rec['name'],'pass':passed})
    for i,s in enumerate(rec['segments']):
        np.savez_compressed(out/(rec['name'].replace('.mat','')+f'-segment{i}.npz'),**{k:v for k,v in s.items() if isinstance(v,np.ndarray)})
all_hashes=[r['source_sha256'] for r in fit['metrics']+metrics]
assert len(all_hashes)==len(set(all_hashes))
report={'status':'RESPONSE_GATE_PASS' if all(x['pass'] for x in checks) else 'RESPONSE_GATE_FAIL','metrics':metrics,'checks':checks,'fit_sha256':hashlib.sha256((ROOT/'fit01/FIT_LOCK01.json').read_bytes()).hexdigest(),'plan_sha256':hashlib.sha256((ROOT/'PREFLIGHT_PLAN01.json').read_bytes()).hexdigest(),'all_source_files_distinct':True,'unit':'four distinct recorded manoeuvres, same campaign/vehicle; no population inference','no_refit':True,'at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(out/'RESPONSE_GATE01.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
