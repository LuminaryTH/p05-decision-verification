"""Complete locked interface/replay matrix for the empirical yaw surrogate."""
import argparse, datetime, hashlib, json, os, resource, sys, time
from pathlib import Path
import numpy as np
from scipy.linalg import expm
from response_preflight01 import ROOT, PLAN, segments

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()

def transition(params,method,h):
    k,t1,t2=params
    A=np.array([[-1/t1,0,k/t1],[1/t2,-1/t2,0],[0,0,0]],float)
    if method=='exact': return expm(A*0.01)
    q=A*h; I=np.eye(3)
    if method=='Euler': step=I+q
    elif method=='RK4': step=I+q+q@q/2+q@q@q/6+q@q@q@q/24
    else: raise ValueError(method)
    n=round(0.01/h); assert abs(n*h-0.01)<1e-12
    return np.linalg.matrix_power(step,n)

def command(target,r,v,k,gain,interface):
    value=float(np.clip((target+gain*(target-r))/(k*v),-3,3))
    if interface=='quantized':
        grid=np.linspace(-3,3,99)
        value=float(grid[np.argmin(np.abs(grid-value))])
    return value

def simulate(s,params,gain,interface,M,schedule=None):
    n=len(s['r']); states=np.zeros((n,2)); applied=np.zeros(n); commands=[]
    state=np.array([s['r'][0],s['r'][0]],float)
    for j in range(n):
        states[j]=state
        if j%10==0:
            u=command(s['r'][j],state[1],s['v'][j],params[0],gain,interface) if schedule is None else float(schedule[j//10])
            commands.append(u)
        applied[j]=u
        state=M[:2,:2]@state+M[:2,2]*(s['v'][j]*u)
        assert np.all(np.isfinite(state)) and np.max(np.abs(state))<=5
    residual=states[:,1]-s['r']
    loss=np.minimum(25,(residual/0.1)**2)
    return {'states':states,'applied':applied,'schedule':np.array(commands),'residual':residual,'sample_loss':loss,'score':float(np.mean(loss[100:])),'rms_rad_s':float(np.sqrt(np.mean(residual[100:]**2)))}

def choice(gap): return 'quantized' if gap < -1e-12 else 'continuous'
def sign(gap): return -1 if gap < -1e-12 else (1 if gap>1e-12 else 0)
def regret(scores,selected): return scores[selected]-min(scores.values())

def tests(params):
    A=np.array([[-1/params[1],0,params[0]/params[1]],[1/params[2],-1/params[2],0],[0,0,0]],float)
    for method,h in [('Euler',.01),('Euler',.00015625),('RK4',.01)]:
        mat=transition(params,method,h); q=A*h; step=np.eye(3)+q
        if method=='RK4': step+=q@q/2+q@q@q/6+q@q@q@q/24
        state=np.array([.1,-.2,1.3]); expected=state.copy()
        for _ in range(round(.01/h)): expected=step@expected
        assert np.max(np.abs(mat@state-expected))<1e-12
    assert command(0,0,10,params[0],.5,'quantized')==0
    for value in [-4,-.1,0,.1,4]:
        z=command(value,0,10,params[0],.5,'quantized'); assert -3<=z<=3
    return 'PASS_MATRIX_MICROSTEP_ZERO_AND_SATURATION'

def main():
    parser=argparse.ArgumentParser(); parser.add_argument('--out',required=True); args=parser.parse_args()
    out=ROOT/args.out; out.mkdir(exist_ok=False)
    start=time.monotonic(); plan=json.loads((ROOT/'INTERFACE_PLAN01.json').read_text()); fit=json.loads((ROOT/'fit01/FIT_LOCK01.json').read_text())
    assert sha(ROOT/'fit01/FIT_LOCK01.json')==plan['fit_lock_sha256']
    assert sha(ROOT/'holdout01/RESPONSE_GATE01.json')==plan['response_gate_sha256']
    params=[fit['params'][key] for key in ['K','tau1_s','tau2_s']]; test=tests(params)
    rows=[]; condition_results=[]; replay_rows=[]; raw_manifest={}
    def save(name,result):
        arrays={k:v for k,v in result.items() if isinstance(v,np.ndarray)}
        p=out/(name+'.npz'); np.savez_compressed(p,**arrays); raw_manifest[p.name]=sha(p)
    for name in PLAN['holdout_files']:
      record=segments(name)
      for segno,s in enumerate(record['segments']):
       for gain in [.5,1.]:
        cid=name.replace('.mat','')+f'-s{segno}-g{gain}'
        info={'condition':cid,'record':name,'segment':segno,'gain':gain,'samples':len(s['r']),'start_s':s['start_s'],'end_s':s['end_s']}
        exact={}
        for interface in ['continuous','quantized']:
            r=simulate(s,params,gain,interface,transition(params,'exact',None)); exact[interface]=r
            save(cid+'-exact-'+interface,r)
            rows.append(dict(info,method='exact',h_ms=None,interface=interface,score=r['score'],rms_rad_s=r['rms_rad_s']))
        for method in plan['integrators']:
            results=[]
            for hms in plan['steps_ms']:
                pair={}
                for interface in ['continuous','quantized']:
                    r=simulate(s,params,gain,interface,transition(params,method,hms/1000)); pair[interface]=r
                    save(cid+f'-{method}-{hms}-'+interface,r)
                    rows.append(dict(info,method=method,h_ms=hms,interface=interface,score=r['score'],rms_rad_s=r['rms_rad_s']))
                results.append(pair)
            gaps=[r['quantized']['score']-r['continuous']['score'] for r in results]
            choices=[choice(g) for g in gaps]; origin=choices[0]
            pathreg=[regret({a:r[a]['score'] for a in r},origin) for r in results]
            exactscores={a:r['score'] for a,r in exact.items()}
            condition_results.append(dict(info,method=method,gaps=gaps,choices=choices,strict_endpoint_reversal=sign(gaps[0])*sign(gaps[-1])==-1,adjacent_strict_reversals=sum(sign(a)*sign(b)==-1 for a,b in zip(gaps[:-1],gaps[1:])),origin_regret_finest=pathreg[-1],origin_max_path_regret=max(pathreg),interior_departure_endpoint_agree=choices[0]==choices[-1] and any(c!=origin for c in choices[1:-1]),exact_gap=exactscores['quantized']-exactscores['continuous'],origin_regret_exact=regret(exactscores,origin),finest_regret_exact=regret(exactscores,choices[-1])))
            rc,rf=results[0],results[-1]
            components={}
            for interface in ['continuous','quantized']:
                crossfine=simulate(s,params,gain,interface,transition(params,method,.00015625),schedule=rc[interface]['schedule'])
                crosscoarse=simulate(s,params,gain,interface,transition(params,method,.01),schedule=rf[interface]['schedule'])
                save(cid+'-'+method+'-crossfine-'+interface,crossfine); save(cid+'-'+method+'-crosscoarse-'+interface,crosscoarse)
                Cc=rc[interface]['score']; Fc=crossfine['score']; Cf=crosscoarse['score']; Ff=rf[interface]['score']
                N=.5*((Fc-Cc)+(Ff-Cf)); B=.5*((Cf-Cc)+(Ff-Fc)); I=Ff-Fc-Cf+Cc
                assert abs(N+B-(Ff-Cc))<1e-12
                components[interface]={'Cc':Cc,'Fc':Fc,'Cf':Cf,'Ff':Ff,'N':N,'B':B,'I':I,'Nc':Fc-Cc,'Bf':Ff-Fc,'Bc':Cf-Cc,'Nf':Ff-Cf}
            gapcomp={k:components['quantized'][k]-components['continuous'][k] for k in components['continuous']}
            replay_rows.append(dict(info,method=method,components=components,gap_components=gapcomp,opposing=gapcomp['N']*gapcomp['B']<0,cancellation=abs(gapcomp['N'])+abs(gapcomp['B'])-abs(gapcomp['N']+gapcomp['B'])))
    assert len(condition_results)==24 and len(rows)==360 and len(replay_rows)==24 and len(raw_manifest)==456
    summary=[]
    for method in ['Euler','RK4']:
      for record in PLAN['holdout_files']:
        subset=[r for r in condition_results if r['method']==method and r['record']==record]
        rep=[r for r in replay_rows if r['method']==method and r['record']==record]
        summary.append({'method':method,'record':record,'conditions':len(subset),'endpoint_reversals':sum(r['strict_endpoint_reversal'] for r in subset),'adjacent_reversals':sum(r['adjacent_strict_reversals'] for r in subset),'endpoint_agree_departures':sum(r['interior_departure_endpoint_agree'] for r in subset),'mean_origin_regret_finest':float(np.mean([r['origin_regret_finest'] for r in subset])),'max_origin_path_regret':max(r['origin_max_path_regret'] for r in subset),'mean_origin_regret_exact':float(np.mean([r['origin_regret_exact'] for r in subset])),'mean_finest_regret_exact':float(np.mean([r['finest_regret_exact'] for r in subset])),'opposing_replays':sum(r['opposing'] for r in rep),'max_abs_gap_N':max(abs(r['gap_components']['N']) for r in rep),'max_abs_gap_B':max(abs(r['gap_components']['B']) for r in rep)})
    report={'status':'COMPLETE_LOCKED_MATRIX','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'plan_sha256':sha(ROOT/'INTERFACE_PLAN01.json'),'code_sha256':sha(Path(__file__)),'conditions':condition_results,'replay':replay_rows,'scores':rows,'summary':summary,'tests':test,'raw_files':raw_manifest,'raw_count':len(raw_manifest),'elapsed_s':time.monotonic()-start,'process_cpu_s':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'scope':'Four measured holdout records; six dependent segments x two fixed gains; no extra independent physical trials or population inference'}
    (out/'RESULTS01.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({k:report[k] for k in ['status','summary','raw_count','elapsed_s','process_cpu_s','max_rss_kib']},indent=2))
    assert report['process_cpu_s']<600 and report['elapsed_s']<900
if __name__=='__main__': main()
