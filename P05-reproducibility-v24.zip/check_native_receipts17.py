"""Portable standard-library reconstruction from frozen native-verification receipts.
Does not run a simulator or claim to re-read original native arrays.
"""
from pathlib import Path
import hashlib,json,math
ROOT=Path(__file__).resolve().parent
C=ROOT/'compact-verification'
def sha(q): return hashlib.sha256(q.read_bytes()).hexdigest()
def avg(xs): return math.fsum(xs)/len(xs)
def choose(x): return 'dense99' if x < -1e-12 else 'continuous'
original=json.loads((C/'original-score-index17.json').read_text())
prov=json.loads((C/'index-provenance17.json').read_text())
assert sha(C/'original-score-index17.json')==prov['compact_sha256']
manifest=json.loads((C/'receipt-manifest01.json').read_text());fresh={};guards={'rank':0,'replay':0}
assert len(manifest)==252
for relative,h in sorted(manifest.items()):
 q=C/relative;assert sha(q)==h,relative
 j=json.loads(q.read_text());kind=j['job']['kind']
 assert not j['discrepancies'] and j['raw_identical']==j['rows']==j['job']['required_rows']
 for x in j['records']:
  k=x['key'];assert k not in fresh;fresh[k]=x;o=original[k]
  assert abs(x['score']-o['bounded_cost'])<=1e-10
  assert x['failure']==o['failure'] and x['raw_identical'] and x['raw_sha256']==o['raw_sha256']
  guards[kind]+=bool(x['failure'])
assert set(original)==set(fresh) and len(fresh)==8976
assert guards=={'rank':245,'replay':0}
def scored(key):
 row=fresh[key];return 25.0 if row['failure'] else row['score']
rank=[]
for draw in range(69300,69364):
 for model in ['full','reduced']:
  for terrain in ['base','steeper']:
   for gain in ['g070','g080']:
    for task in ['straight','left','right']:
     gaps=[]
     for ns in [312500,156250]:
      base=f'rank:{model}:{draw}:{terrain}-s{ns}-automatic-'
      gaps.append(scored(base+'dense99-'+gain+'-'+task)-scored(base+'continuous-'+gain+'-'+task))
     strict=(gaps[0]<-1e-12 and gaps[1]>1e-12) or (gaps[0]>1e-12 and gaps[1]<-1e-12)
     retained=choose(gaps[0]);cost=max(0.0,gaps[1] if retained=='dense99' else -gaps[1])
     rank.append((strict,cost,retained!=choose(gaps[1])))
assert len(rank)==1536
replay=[]
for cond in json.loads((C/'eligibility01.json').read_text()):
 if not cond['eligible']:continue
 components=[]
 for interface in ['dense99','continuous']:
  scores=[]
  for group,origin,target in [('pilot',5000000,5000000),('replay',5000000,312500),('replay',312500,5000000),('pilot',312500,312500)]:
   k=f"replay:{group}_c{origin}_{cond['model']}:{cond['draw']}:{cond['distribution']}-s{target}-automatic-{interface}-{cond['gain']}-{cond['task']}"
   assert not fresh[k]['failure'];scores.append(fresh[k]['score'])
  cc,fc,cf,ff=scores
  components.append(((fc-cc+ff-cf)/2,(cf-cc+ff-fc)/2,ff-fc-cf+cc,ff-cc))
 n,b,i,t=[components[0][k]-components[1][k] for k in range(4)]
 assert abs(n+b-t)<=1e-10
 replay.append(dict(draw=cond['draw'],n=n,b=b,i=i,t=t))
assert len(replay)==354
assert len({x['draw'] for x in replay})==16
def weighted(fn):return avg([avg([fn(x) for x in replay if x['draw']==d]) for d in range(69120,69136)])
gross=weighted(lambda x:abs(x['n'])+abs(x['b']));net=weighted(lambda x:abs(x['t']))
result=dict(rank_conditions=len(rank),strict_reversals=sum(x[0] for x in rank),choice_changes=sum(x[2] for x in rank),mean_regret=avg([x[1] for x in rank]),replay_eligible=len(replay),replay_opposition=sum(x['n']*x['b']<0 for x in replay),gross=gross,abs_net=net,compensation=1-net/gross)
ref=json.loads((C/'FINAL-AUDIT01.json').read_text())['new_aggregates']
checks={'rank_conditions':ref['rank']['conditions'],'strict_reversals':ref['rank']['strict_reversals'],'choice_changes':ref['rank']['choice_changes'],'mean_regret':ref['rank']['mean_regret'],'replay_eligible':ref['replay']['eligible'],'replay_opposition':ref['replay']['opposite'],'gross':ref['replay']['gross'],'abs_net':ref['replay']['abs_T'],'compensation':ref['replay']['compensation']}
assert all(abs(result[k]-v)<=1e-10 for k,v in checks.items())
print(json.dumps(dict(status='PASS_COMPACT_ARITHMETIC',episodes=len(fresh),jobs=len(manifest),guardrails=guards,result=result,added_independent_draws=0,scope='Checks all frozen per-episode receipts and independently reconstructs reported arithmetic. Does not re-read native arrays or perform native simulation.'),indent=2))
