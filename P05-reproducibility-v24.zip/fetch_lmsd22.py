"""Retrieve or verify six fixed official records; never select by outcome."""
import argparse
import hashlib
import json
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parent

def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            h.update(block)
    return h.hexdigest()

def main():
    parser = argparse.ArgumentParser()
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--verify-dir", type=Path)
    mode.add_argument("--download-to", type=Path)
    args = parser.parse_args()
    manifest = json.loads((ROOT / "LMSD-SOURCES22.json").read_text())
    target = (args.verify_dir or args.download_to).resolve()
    if args.download_to:
        target.mkdir(parents=True, exist_ok=True)
    checked = []
    for record in manifest["files"]:
        name = record["name"]
        assert Path(name).name == name and name.endswith(".mat")
        path = target / name
        if args.download_to:
            assert not path.exists(), "Refusing existing source: " + name
            assert record["url"].startswith("https://rdr.kuleuven.be/api/access/datafile/")
            partial = path.with_suffix(".mat.part")
            with partial.open("xb") as output:
                with urllib.request.urlopen(record["url"], timeout=30) as response:
                    remaining = record["bytes"] + 1
                    while remaining:
                        block = response.read(min(65536, remaining))
                        if not block:
                            break
                        output.write(block)
                        remaining -= len(block)
            assert partial.stat().st_size == record["bytes"], name
            assert digest(partial) == record["sha256"], name
            partial.rename(path)
        assert path.stat().st_size == record["bytes"], name
        assert digest(path) == record["sha256"], name
        checked.append({"name": name, "sha256": record["sha256"]})
    print(json.dumps({"status": "PASS_SOURCE_IDENTITY", "files": checked,
                      "mode": "verification_only" if args.verify_dir else "downloaded",
                      "boundary": "Source identity only; no fit, simulation or release permission."}, indent=2))

if __name__ == "__main__":
    main()
