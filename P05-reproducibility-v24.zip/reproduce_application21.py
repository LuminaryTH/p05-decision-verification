"""Reproduce the new application in fresh directories without modifying historical locks."""
import argparse,hashlib,json,os,shutil,subprocess,sys,datetime
from pathlib import Path
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'experiment21'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);args=ap.parse_args()
    out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
    files=['PREFLIGHT_PLAN01.json','INTERFACE_PLAN01.json','response_preflight01.py','interface_experiment01.py','independent_consumer01.py','response_independent01.py','calibration-download01.json','holdout-download01.json']
    files += [p.name for p in SOURCE.glob('*.mat')]
    for name in files: shutil.copy2(SOURCE/name,out/name)
    shutil.copytree(SOURCE/'fit01',out/'fit01');shutil.copytree(SOURCE/'holdout01',out/'holdout01')
    env=dict(os.environ,OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONHASHSEED='20261023')
    runs=[]
    def execute(script,folder=out,extra=()):
        argv=[sys.executable,str(folder/script),*extra]
        r=subprocess.run(argv,cwd=folder,env=env,capture_output=True,text=True,timeout=600)
        tag=script.replace('.py','')+str(len(runs));(out/(tag+'-stdout.txt')).write_text(r.stdout);(out/(tag+'-stderr.txt')).write_text(r.stderr)
        runs.append({'argv':argv,'exit':r.returncode});assert r.returncode==0,r.stderr
    fitcheck=out/'fit-recheck';fitcheck.mkdir()
    for name in ['PREFLIGHT_PLAN01.json','response_preflight01.py']+[v['name'] for v in json.loads((SOURCE/'calibration-download01.json').read_text())]:shutil.copy2(SOURCE/name,fitcheck/name)
    execute('response_preflight01.py',fitcheck)
    expected=json.loads((SOURCE/'fit01/FIT_LOCK01.json').read_text());actual=json.loads((fitcheck/'fit01/FIT_LOCK01.json').read_text())
    for k,v in expected['params'].items():assert abs(v-actual['params'][k])<1e-12
    execute('interface_experiment01.py',extra=('--out','experiment01'))
    execute('interface_experiment01.py',extra=('--out','experiment02'))
    for run in ['experiment01','experiment02']:
        old=json.loads((SOURCE/run/'RESULTS01.json').read_text());new=json.loads((out/run/'RESULTS01.json').read_text())
        assert old['raw_files']==new['raw_files'] and old['scores']==new['scores'] and old['conditions']==new['conditions'] and old['replay']==new['replay']
    execute('independent_consumer01.py');execute('response_independent01.py')
    report={'status':'PASS_FRESH_PACKAGE_APPLICATION_REPRODUCTION','at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'fit_parameters_reproduced':True,'two_fresh_matrices_match_original_456_raw_hashes_each':True,'separate_interface_and_response_consumers':'PASS','runs':runs,'out':str(out),'boundary':'Same pinned runtime; separate arithmetic by same assistant; zero new physical units.'}
    (out/'REPRODUCTION21.json').write_text(json.dumps(report,indent=2));print(json.dumps(report,indent=2))
if __name__=='__main__':main()
