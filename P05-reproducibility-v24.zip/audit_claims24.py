"""Reconstruct key manuscript quantities from retained score records, offline."""
from collections import defaultdict
from pathlib import Path
import csv
import hashlib
import json
import math

ROOT = Path(__file__).resolve().parent
TOL = 1e-12


def sign(x):
    return 1 if x > TOL else -1 if x < -TOL else 0


def avg(xs):
    return math.fsum(xs) / len(xs)


def load(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))


def run():
    cohorts = defaultdict(list)
    for name in ['transitions.csv', 'transitions-cpu.csv']:
        with (ROOT / 'figure-data' / name).open(newline='') as f:
            for x in csv.DictReader(f):
                if name == 'transitions-cpu.csv':
                    x = dict(x,cohort='cpu32',original_gap=x['gap312500'],finer_gap=x['gap156250'],old_choice_finer_regret=x['retained_choice_finer_regret'])
                cohorts[x['cohort']].append(x)
    out = {'scope': 'Retained-score arithmetic; no new simulation or physical validation', 'cohorts': {}}
    counts = {'trace26':450, 'replication27r03':410, 'cpu32':434}
    means = {'trace26':0.012002024, 'replication27r03':0.008834955, 'cpu32':0.009064559}
    for name, rows in cohorts.items():
        assert len(rows) == 1536 and len({x['draw'] for x in rows}) == 64
        assert len({(x['draw'],x['key']) for x in rows}) == 1536
        reversals = 0
        costs = []
        for x in rows:
            a,b = float(x['original_gap']),float(x['finer_gap'])
            assert math.isfinite(a) and math.isfinite(b)
            reversal = sign(a)*sign(b) == -1
            if 'strict_reversal' in x:
                assert reversal == (x['strict_reversal']=='True')
            else:
                # Historical field includes negative-to-tie choice changes.
                assert ((sign(a)<0)!=(sign(b)<0)) == (x['preference_reversal']=='True')
            cost = max(0.0, b if sign(a)<0 else -b)
            if abs(b)<=TOL: cost=0.0
            assert abs(cost-float(x['old_choice_finer_regret'])) < 1e-10
            reversals += reversal
            costs.append(cost)
        assert reversals == counts[name] and abs(avg(costs)-means[name]) < 5e-10
        out['cohorts'][name] = dict(independent_draws=64,dependent_conditions=1536,reversals=reversals,fraction=reversals/1536,mean_regret=avg(costs),affected_mean=avg([v for v in costs if v>0]))
    terrain = {}
    for name in ['base','steeper']:
        rows = [x for x in cohorts['cpu32'] if x['key'].split('|')[1]==name]
        assert len(rows)==768 and len({x['draw'] for x in rows})==64
        terrain[name] = dict(conditions=len(rows),draws=64,reversals=sum(sign(float(x['original_gap']))*sign(float(x['finer_gap']))==-1 for x in rows),mean_regret=avg([float(x['old_choice_finer_regret']) for x in rows]))
    assert terrain['base']['reversals']==229 and terrain['steeper']['reversals']==205
    assert terrain['base']['mean_regret'] < terrain['steeper']['mean_regret']
    out['table9_terrain'] = terrain

    bullet=load('figure-data/bullet-paired-scores.json')
    assert not bullet['unavailable']
    scores={}
    pair_map={p['id']:p for p in bullet['design']['step_pairs']}
    unique=set()
    for x in bullet['records']:
        key=(x['draw'],x['condition'],x['pair_id'],x['interface'])
        assert key not in unique
        unique.add(key)
        pair=pair_map[x['pair_id']]
        for step,field in [(pair['coarse_ns'],'cc'),(pair['fine_ns'],'ff')]:
            k=(x['draw'],x['condition'],step,x['interface'])
            value=x[field]
            assert math.isfinite(value)
            if k in scores: assert abs(scores[k]-value)<1e-10
            scores[k]=value
    assert len(unique)==384*6*2
    ladder=sorted({k[2] for k in scores},reverse=True)
    departures=[]
    transitions=0
    costs=[]
    for d in bullet['design']['draws']:
        for c in bullet['design']['conditions']:
            gaps=[scores[d,c,h,'quantized']-scores[d,c,h,'unprojected'] for h in ladder]
            s=[sign(v) for v in gaps]
            assert s[0]==s[-1]
            transitions+=sum(a*b==-1 for a,b in zip(s,s[1:]))
            origin='quantized' if s[0]<0 else 'unprojected'
            path=[max(0.0,v if origin=='quantized' else -v) for v in gaps]
            costs.append(max(path))
            if max(path)>TOL: departures.append(dict(draw=d,condition=c,origin=origin,maximum_origin_path_regret=max(path)))
    assert len(costs)==384 and transitions==4 and len(departures)==2
    assert abs(max(costs)-0.025138315)<5e-10
    out['bullet']=dict(draws=32,conditions=384,steps=ladder,endpoint_choice_changes=0,adjacent_strict_transitions=transitions,departures=departures,mean_path_maximum=avg(costs))

    app=load('experiment21/experiment01/RESULTS01.json')
    out['application']={}
    for method in ['Euler','RK4']:
        rows=[x for x in app['conditions'] if x['method']==method]
        assert len(rows)==12 and len({x['record'] for x in rows})==4
        transitions=sum(sum(sign(a)*sign(b)==-1 for a,b in zip(x['gaps'],x['gaps'][1:])) for x in rows)
        endpoints=sum(sign(x['gaps'][0])*sign(x['gaps'][-1])==-1 for x in rows)
        returning=sum(sign(x['gaps'][0])==sign(x['gaps'][-1]) and any(sign(v)*sign(x['gaps'][0])==-1 for v in x['gaps'][1:-1]) for x in rows)
        maximum=max(x['origin_max_path_regret'] for x in rows)
        assert (endpoints,transitions,returning)==((7,15,3) if method=='Euler' else (0,0,0))
        assert all(sign(x['gaps'][-1])==sign(x['exact_gap']) for x in rows)
        if method=='RK4': assert maximum==0 and all(all(sign(v)==sign(x['exact_gap']) for v in x['gaps']) for x in rows)
        else: assert abs(maximum-0.0006596652880952458)<1e-16
        out['application'][method]=dict(heldout_records=4,dependent_conditions=12,endpoint_reversals=endpoints,adjacent_transitions=transitions,returning_paths=returning,max_origin_path_regret=maximum)
    gate=load('experiment21/holdout01/RESPONSE_GATE01.json')
    assert gate['status']=='RESPONSE_GATE_PASS' and len(gate['metrics'])==4
    for x in gate['metrics']:
        assert x['RMSE_rad_s']<=.1 and x['NRMSE']<=.6 and x['correlation']>=.8 and x['scored_duration_s']>=5
    out['response_RMSE_range_rad_s']=[min(x['RMSE_rad_s'] for x in gate['metrics']),max(x['RMSE_rad_s'] for x in gate['metrics'])]
    out['status']='PASS'
    return out


if __name__=='__main__':
    print(json.dumps(run(),indent=2))
